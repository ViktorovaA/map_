import requests


def create_map(coords, l="map", spn=0.005, size=[650, 450], points=[]):
    map_params = {
        "ll": coords,
        "spn": ",".join(map(lambda x: str(x), [spn, spn])),
        "l": l,
        "size": ",".join(map(lambda x: str(x), size)),
        "pt": "~".join(points)
    }

    map_api_server = "http://static-maps.yandex.ru/1.x/"
    response = requests.get(map_api_server, params=map_params)
    if not response:
        raise Exception("ошибка запроса")
    return response.content