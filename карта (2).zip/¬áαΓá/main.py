import sys
from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt
from PyQt5 import uic
from coordinates import coordinates     # Возваращает координаты из запроса
from map import create_map              # Создает картинку
from find import find                   # Возвращает информацию поиска
import os


class MainWindow(QMainWindow):  # Главное окно
    def __init__(self):
        super().__init__()
        uic.loadUi("1.ui", self)

        # Значения для создания карты
        self.spn = 0.01
        self.z = 13
        self.type = "map"
        self.lat = 48.746845
        self.lon = 55.747976
        self.points = ["{},pm2rdl".format(",".join(map(lambda x: str(x), [self.lat, self.lon])))]
        self.address_str = "ИННННОПОООЛИС"
        self.postcode_srt = "420500"
        self.postcode_show = True

        # Кнопки
        self.button_find.clicked.connect(self.get_coords)
        self.plus.clicked.connect(self.spn_plus)
        self.minus.clicked.connect(self.spn_minus)
        self.map.toggled.connect(self.change_type)
        self.map.type = "map"
        self.sat.toggled.connect(self.change_type)
        self.sat.type = "sat"
        self.skl.toggled.connect(self.change_type)
        self.skl.type = "sat,skl"
        self.reset.clicked.connect(self.resetting_the_result)
        self.index.clicked.connect(self.index_mode)

    # Получает координаты места
    def get_coords(self):
        toponym_to_find = self.lineEdit.text()
        if not toponym_to_find:
            toponym_to_find = "иннополис квантовый бульвар 1"
        toponym_to_find = "".join(toponym_to_find.split(","))

        response = find(toponym_to_find)
        # Проверяет, нашлось ли что-либо
        if len(response.json()["response"]["GeoObjectCollection"]["featureMember"]) == 0:
            image = "images/noFind.png"
            self.label.setPixmap(QPixmap(image))
            self.address.setText("")
            self.postcode.setText("")
        else:
            toponym_to_find = response.json()["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
            self.address_str = toponym_to_find["metaDataProperty"]["GeocoderMetaData"]["text"]
            self.postcode_srt = toponym_to_find["metaDataProperty"]["GeocoderMetaData"]["Address"].get("postal_code")

            if self.postcode_srt is None:
                self.postcode_srt = "не найдено"

            coords = ",".join(coordinates(response))
            # Добавление точки
            p = "{},pm2rdl".format(coords)
            if p in self.points:
                del self.points[self.points.index(p)]
            self.points.append("{},pm2rdl".format(coords))

            self.lat = float(coords.split(",")[0])
            self.lon = float(coords.split(",")[1])

            self.get_image_coords()

    # Создание и отображение картинки
    def get_image_coords(self):
        if self.type == "map":
            image = "images/map.png"
        else:
            image = "images/map.jpg"
        try:
            coords = map(lambda x: str(x), [self.lat, self.lon])
            coords = ",".join(coords)
            with open(image, "wb") as file:
                file.write(create_map(coords, l=self.type, spn=self.spn, points=self.points))
        except Exception as error:
            print(error.__class__.__name__, error)
        self.label.setPixmap(QPixmap(image))
        os.remove(image)
        # Отображение адреса и индекса
        self.address.setText(self.address_str)
        if self.postcode_show:
            self.postcode.setText(self.postcode_srt)
        else:
            self.postcode.setText("")

    # Увеличивание
    def spn_plus(self):
        if self.spn >= 0.011:
            step = 0.1
        elif self.spn <= 0.0031:
            step = 0.001
        else:
            step = 0.005
        self.spn = max(0, self.spn - step)
        self.get_image_coords()

    # Уменьшение
    def spn_minus(self):
        if self.spn >= 0.01:
            step = 0.1
        elif self.spn <= 0.002:
            step = 0.001
        else:
            step = 0.005
        self.spn = min(17, self.spn + step)
        self.get_image_coords()

    # Спена типа карты
    def change_type(self):
        radioButton = self.sender()
        if radioButton.isChecked():
            self.type = radioButton.type
        self.get_image_coords()

    # Обработка событий клавиатуры
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Plus or event.key() == Qt.Key_Equal:
            self.spn_plus()
            self.get_image_coords()
        elif event.key() == Qt.Key_Minus:
            self.spn_minus()
            self.get_image_coords()
        elif event.key() == Qt.Key_W:
            if self.spn == 0:
                self.lon = min(self.lon + 0.0005, 85)
            else:
                self.lon = min(self.lon + 0.8 * self.spn, 85)
            self.get_image_coords()
        elif event.key() == Qt.Key_S:
            if self.spn == 0:
                self.lon = max(self.lon - 0.0005, -85)
            else:
                self.lon = max(self.lon - 0.8 * self.spn, -85)
            self.get_image_coords()
        elif event.key() == Qt.Key_A:
            if self.spn == 0:
                self.lat = max(self.lat - 0.001, -179.999)
            else:
                self.lat = max(self.lat - self.spn, -179.999)
            self.get_image_coords()
        elif event.key() == Qt.Key_D:
            if self.spn == 0:
                self.lat = min(self.lat + 0.001, 179.999)
            else:
                self.lat = min(self.lat + self.spn, 179.999)
            self.get_image_coords()

    # сброс поисковых результатов
    def resetting_the_result(self):
        if len(self.points) > 1:
            del self.points[-1]
        self.address_str = ""
        self.postcode_srt = ""
        self.get_image_coords()

    # Включение и выключение индекса
    def index_mode(self):
        if self.postcode_show:
            self.postcode_show = False
        else:
            self.postcode_show = True
        self.get_image_coords()


try:
    app = QApplication(sys.argv)
    ex = MainWindow()
    ex.show()
    sys.exit(app.exec_())
except Exception as error:
    print(error)
